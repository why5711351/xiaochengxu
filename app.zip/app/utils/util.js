const app = getApp()
let serveradd = app.globalData.serveradd;
/**
 * 数据处理
 * @author echo.
 * @version 1.5.1
 **/
const utils = {
	//去空格
	trim: function (value) {
		return value.replace(/(^\s*)|(\s*$)/g, "");
	},
	//内容替换
	replaceAll: function (text, repstr, newstr) {
		return text.replace(new RegExp(repstr, "gm"), newstr);
	},
	//格式化手机号码
	formatNumber: function (num) {
		return num.length === 11 ? num.replace(/^(\d{3})\d{4}(\d{4})$/, '$1****$2') : num;
	},
	//金额格式化
	rmoney: function (money) {
		return parseFloat(money).toFixed(2).toString().split('').reverse().join('').replace(/(\d{3})/g, '$1,').replace(
			/\,$/, '').split('').reverse().join('');
	},
	//日期格式化
	formatDate: function (formatStr, fdate) {
		if (fdate) {
			if (~fdate.indexOf('.')) {
				fdate = fdate.substring(0, fdate.indexOf('.'));
			}
			fdate = fdate.toString().replace('T', ' ').replace(/\-/g, '/');
			var fTime, fStr = 'ymdhis';
			if (!formatStr)
				formatStr = "y-m-d h:i:s";
			if (fdate)
				fTime = new Date(fdate);
			else
				fTime = new Date();
			var month = fTime.getMonth() + 1;
			var day = fTime.getDate();
			var hours = fTime.getHours();
			var minu = fTime.getMinutes();
			var second = fTime.getSeconds();
			month = month < 10 ? '0' + month : month;
			day = day < 10 ? '0' + day : day;
			hours = hours < 10 ? ('0' + hours) : hours;
			minu = minu < 10 ? '0' + minu : minu;
			second = second < 10 ? '0' + second : second;
			var formatArr = [
				fTime.getFullYear().toString(),
				month.toString(),
				day.toString(),
				hours.toString(),
				minu.toString(),
				second.toString()
			]
			for (var i = 0; i < formatArr.length; i++) {
				formatStr = formatStr.replace(fStr.charAt(i), formatArr[i]);
			}
			return formatStr;
		} else {
			return "";
		}
	},
	rgbToHex: function (r, g, b) {
		return "#" + utils.toHex(r) + utils.toHex(g) + utils.toHex(b)
	},
	toHex: function (n) {
		n = parseInt(n, 10);
		if (isNaN(n)) return "00";
		n = Math.max(0, Math.min(n, 255));
		return "0123456789ABCDEF".charAt((n - n % 16) / 16) +
			"0123456789ABCDEF".charAt(n % 16);
	},
	hexToRgb(hex) {
		let result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
		return result ? {
			r: parseInt(result[1], 16),
			g: parseInt(result[2], 16),
			b: parseInt(result[3], 16)
		} : null;
	}
}
/**
 * POST 请求
 * model:{
 * url:接口
 * postData:参数 {}
 * doSuccess:成功的回调
 *  doFail:失败回调
 * }
 */
function vpost(model) {
  wx.showLoading({
    title: '加载中',
  })
  wx.request({
    url: serveradd + model.url,
    header: {
      "Content-Type": "application/x-www-form-urlencoded"
    },
    method: "POST",
    data: model.data,
    success: (res) => {
      model.success(res.data)
      wx.hideLoading({
        success: (res) => {},
      })
    },
    fail: (res) => {
      model.fail(res.data)
      wx.hideLoading({
        success: (res) => {
          wx.showToast({
            title: '加载失败',
            icon: 'error'
          })
        },
      })
    }
  })
}

/**
 * GET 请求
 * model:{
 *  url:接口
 *  getData:参数 {}
 *  doSuccess:成功的回调
 *  doFail:失败回调
 * }
 */
function vget(model) {
  wx.showLoading({
    title: '加载中',
  })
  wx.request({
    url: serveradd + model.url,
    data: model.data,
    success: (res) => {
      model.success(res.data)
      wx.hideLoading({
        success: (res) => {},
      })
    },
    fail: (res) => {
      model.fail(res.data)
      wx.hideLoading({
        success: (res) => {
          wx.showToast({
            title: '加载失败',
            icon: 'error'
          })
        },
      })
    }
  })
}
/**
 * 静默GET 请求
 * model:{
 *  url:接口
 *  getData:参数 {}
 *  doSuccess:成功的回调
 *  doFail:失败回调
 * }
 */
function sget(model) {
  wx.request({
    url: serveradd + model.url,
    data: model.data,
    success: (res) => {
      model.success(res.data)
    },
    fail: (res) => {
      model.fail(res.data)
    }
  })
}
/**
 * 静默GET 请求
 * model:{
 *  url:接口
 *  getData:参数 {}
 *  doSuccess:成功的回调
 *  doFail:失败回调
 * }
 */

function uget(model) {
  wx.request({
    url: model.url,
    data: model.data,
    success: (res) => {
      model.success(res.data)
    },
    fail: (res) => {
      model.fail(res.data)
    }
  })
}
function upost(model) {
  wx.request({
    url: serveradd + model.url,
    header: {
      "Content-Type": "application/x-www-form-urlencoded"
    },
    method: "POST",
    data: model.data,
    success: (res) => {
      model.success(res.data)
    },
    fail: (res) => {
      model.fail(res.data)
    }
  })
}


function scop(model){
  let token = wx.getStorageSync("token"); 
  wx.showModal({
    title:'提示',
    content: '请您授权我们获得您的信息，以便于您更好的使用本程序',
    cancelText:'先看看',
    confirmText:'好的',
    success (res) {
      if (res.confirm) {
        wx.getUserProfile({
          desc: '我们将妥善保管您的信息。', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
          success: (res) => {
            console.log(res.userInfo)
            wx.request({
              url: serveradd +'appserver/user/scop.php',
              header: {
                "Content-Type": "application/x-www-form-urlencoded"
              },
              method: "POST",
              data: {
                nickName:res.userInfo.nickName,
                avatarUrl:res.userInfo.avatarUrl,
                gender:res.userInfo.gender,
                language:res.userInfo.language,
                city:res.userInfo.city,
                country:res.userInfo.country,
                province:res.userInfo.ciprovincety,
                token:token
              },
              success: (res) => {
               wx.redirectTo({
                 url: '/pages/index/index',
               })
              },
              fail: (res) => {
                wx.redirectTo({
                  url: '/pages/index/index',
                })
              }
            })
          }
        })
      
      } else if (res.cancel) {
        wx.redirectTo({
          url: '/pages/index/index',
        })
      }
    }


  })
}

module.exports = {
	trim: utils.trim,
	replaceAll: utils.replaceAll,
	formatNumber: utils.formatNumber,
	rmoney: utils.rmoney,
	formatDate: utils.formatDate,
	rgbToHex: utils.rgbToHex,
	hexToRgb: utils.hexToRgb,
	vget: vget,
  vpost: vpost,
  sget: sget,
	uget: uget,
	upost: upost,
  scop: scop,
}