var app = getApp();
var serveradd = app.globalData.serveradd;
var util = require("../../utils/util.js");
const myaudio = wx.createInnerAudioContext({});
Page({
  data: {
    CustomBar: app.globalData.CustomBar, //顶部栏高度
    serveradd: serveradd, //服务器地址
    swiperList: [{
      id: 0,
      type: 'image',
      url: 'images/4.jpg'
    }, {
      id: 1,
      type: 'image',
      url: 'images/5.jpg',
    }],
    sex: 1,
    dos: '男',
    special: ['无', '田径', '足球', '篮球', '乒乓球', '排球', '体操', '武术'],
    sindex: null,
    specialname: '',
    athletics: ['200米', '400米', '800米', '1500米', '110米栏', '跳高', '跳远', '三级跳远', '撑杆跳高', '铅球', '铁饼', '标枪'],
    aindex: null,
    athleticsname: '',
    jieguo: 0,
    result: []
  },
  onLoad() {

  },
  chsex: function (e) {
    let that = this
    let id = e.currentTarget.dataset.id
    let dos = e.currentTarget.dataset.dos
    let lan = 'athletics[4]'
    if (dos == '男') {
      that.setData({
        [lan]: '110米栏'
      })
    } else {
      that.setData({
        [lan]: '100米栏'
      })
    }
    that.setData({
      sex: id,
      dos: dos
    })

  },
  onShareAppMessage: function () {},
  specialChange(e) {
    let speci = this.data.special[e.detail.value]
    console.log(speci)
    this.setData({
      sindex: e.detail.value,
      specialname: speci,
      athleticsname: ''
    })
  },
  athleticsChange(e) {
    let athl = this.data.athletics[e.detail.value]
    console.log(athl)
    this.setData({
      aindex: e.detail.value,
      athleticsname: athl
    })
  },
  formSubmit(e) {
    let that = this
    let dos = that.data.dos
    let athleticsname = that.data.athleticsname
    let specialname = that.data.specialname
    let {
      qianqiu,
      m100,
      m1001,
      ldty,
      tj1,
      tj2,
      tj3,
      tj4,
      tj5
    } = e.detail.value
    let ok = true
    util.vpost({
      url: "appserver/achievement/post.php",
      data: {
        dos: dos,
        qianqiu: qianqiu,
        m100: m100,
        m1001: m1001,
        ldty: ldty,
        athleticsname: athleticsname,
        tj1: tj1,
        tj2: tj2,
        tj3: tj3,
        tj4: tj4,
        tj5: tj5,
        specialname: specialname,
      },
      success: (res) => {
        console.log(res)
        that.setData({
          result: res,
          jieguo: 1,
          qianqiu: qianqiu,
          m100: m100,
          m1001: m1001,
          ldty: ldty
        })
      },
      fail: (res) => {},
    });
  },
  return(e){
    wx.redirectTo({
      url: '/pages/index/index',
    })
  },viewimg(){
    wx.previewImage({
      urls: ['https://chaxun.4182.cn/imgs/gongzhonghao.jpg'],
    })
  }
});